# Scalar Paper II — Nuclear Physics B supplementary checks

Companion to *Terminal scalar states, Hadamard obstruction and local stress
in the Schwarzschild interior*, Francisco R. Villatoro. This NPB package combines the existing scalar supplement
with the subsequent independent audit. It does not change the mathematical
models, integrations, or production scripts.

## Provenance

- `archived_v110/` preserves the original scalar scripts and outputs from
  `FrancisRVillatoro/schwarzschild-one-particle-reproducibility`, tag v1.1.0,
  DOI 10.5281/zenodo.23154909.
- `check_AoP_revision.py`, `check_scalar_Ward.py`, `reference_results/`,
  `results/`, and `environment.json` are preserved from the 19 October 2026
  submission supplement. The original names and recorded outputs are retained
  for traceability. `historical_README_AoP.md`, `historical_PROVENANCE_AoP.json`,
  and `SHA256SUMS_AoP_original`
  document that earlier package; its original checksum file applies to that
  earlier layout and must not be used to validate the expanded NPB package.
- `independent_audit/` preserves the separately written symbolic and numerical
  audit and its previously recorded output, subsequently included in the
  reproducibility release v1.2.0, DOI 10.5281/zenodo.23743099.
  Its internal manuscript numbering
  refers to the Annals of Physics version. Its README records assistance from
  ChatGPT (OpenAI) and Claude (Anthropic).
- `validation_NPB_20261117/` contains the fresh rerun logs, environment,
  run summary, Ward-test output, and an assessment of the actual residuals.
  The historical reference results have not been overwritten.
- `SHA256SUMS` validates this complete NPB package.

The public archive and the additional files in this supplement are distinct
sources. This packaging step does not create a DOI, alter a published release,
or claim that every supplied file belongs to v1.1.0. `PROVENANCE.json` records
the origin of each component.

## Reproduce the NPB verification

With Python 3.10 or later and the dependencies in `requirements.txt`, run from
the extracted package directory:

```sh
python -m pip install -r requirements.txt
python run_npb_checks.py
```

This driver runs `audit_sym.py`, `check_scalar_Ward.py`, and the complete
`audit_num.py`, including its special-integral calculations. Sources are copied
to a temporary directory for execution. New output is written only to
`validation_NPB_20261117/`; historical outputs remain unchanged.

The full earlier seven-process reproduction remains available:

```sh
python run_all_checks.py
```

That historical driver writes to `results/` and leaves `reference_results/`
unchanged. Package versions used for the new run are recorded in
`validation_NPB_20261117/environment.json`; the root `environment.json`
describes the earlier run.

## What the diagnostics establish

The symbolic audit re-derives the geometry, canonical rescalings, Frobenius
coefficients, radial-geodesic asymptotics, occupation prefactors, and
curvature-coupling improvement. The independent numerical audit checks the
special-function coefficients, radial endpoint connection, printed table
entries, and directional Born benchmark. The Ward script checks the scalar
stress divergence and trace on 20 random on-shell two-jets.

Most independent numerical checks print residuals rather than asserting every
value. An exit code of zero alone is not evidence that every printed identity
has been verified. In particular, finite-regulator Abel quadrature is an
approximate diagnostic, not a certified evaluation of its limiting integral;
the recorded assessment reports its residual separately.

The normalized horizon-profile diagnostic in the earlier supplement divides
the raw scalar field by the square root of
`Z = 2.5086142772483844` and its stress by `Z`. It is not a numerical
construction of exterior transmission for a globally prepared Unruh particle.
No absolute vacuum stress tensor, complete exterior transmission matrix,
uniform generic-ray remainder, or proof of the local Hadamard theorem is
computed by these scripts. Those distinctions are retained in the manuscript
and supplementary note.

Finite calculations provide consistency checks; the analytic arguments and
their stated hypotheses establish the general results.
