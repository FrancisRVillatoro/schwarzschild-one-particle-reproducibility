# NPB verification assessment — 17 November 2026

The three existing scripts completed successfully. The symbolic stdout is
identical to its preserved audit output. The numerical stdout also reproduces
the preserved audit values, apart from elapsed times. All 15 printed occupation
comparisons (seven s-wave and eight fixed-angular-tower rows) match the table
values at their displayed precision. Horizon and Liouville–Green starts give
the same printed coefficients in the dedicated comparison.

The largest norm defect printed among the B1 and B3 rows is 1.9e-11, so the
historical README phrase “1e-11 or better in all cases” should not be read as
a strict global bound. The individual output rows are authoritative.

The independent Ward test passes on 20 random on-shell jets. Its maximum
relative divergence residual is 2.8065886317982205e-16 and its maximum relative
trace residual is 1.0462882938780629e-15.

The directional Born diagnostic has printed percentage deviations -0.44%,
+0.11%, -0.50%, and +0.37%. These are finite-frequency benchmarks, not rigorous
uniform scattering-error bounds.

The finite-regulator Abel extrapolation is approximately
0.20210119 - 0.00060915263i, whereas 2/pi^2 is approximately 0.20264237.
Its relative complex residual is about 0.40%. This reproduces the historical
calculation but does not certify an accurate limiting integral. No stronger
claim is made here. The analytic integral identity is separate from this
coarse numerical diagnostic.

Forty-nine original source/data/provenance files are preserved byte-for-byte,
including copies of the three top-level files whose NPB counterparts were
updated. See source_preservation.json for the per-file hashes. Script names,
including the old AoP label, were retained for traceability.
