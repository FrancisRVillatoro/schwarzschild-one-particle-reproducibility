"""Run scalar Paper-II checks without altering archived source/reference files."""
from __future__ import annotations
from pathlib import Path
import json, os, shutil, subprocess, sys, tempfile, time

ROOT=Path(__file__).resolve().parent
SCRIPTS=("paper2_symbolic_checks.py", "num_checks.py", "run_part1.py",
         "run_part2.py", "generic_ray_check.py")

def main() -> None:
    out=ROOT/"results"; logs=out/"archived_runs"
    logs.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS="1",OMP_NUM_THREADS="1",
               MKL_NUM_THREADS="1",PYTHONDONTWRITEBYTECODE="1")
    records=[]
    with tempfile.TemporaryDirectory(prefix="aop_scalar_checks_") as temp:
        work=Path(temp)/"paper_II"
        shutil.copytree(ROOT/"archived_v110",work)
        jobs=[(s,work,logs/(s+".log")) for s in SCRIPTS]
        jobs += [(s,ROOT,out/(s+".log")) for s in
                 ("check_AoP_revision.py","check_scalar_Ward.py")]
        for i,(name,cwd,log) in enumerate(jobs,1):
            print(f"[{i}/{len(jobs)}] {name}",flush=True)
            t=time.monotonic()
            with log.open("w",encoding="utf-8") as handle:
                proc=subprocess.run([sys.executable,name],cwd=cwd,env=env,
                                    stdout=handle,stderr=subprocess.STDOUT)
            records.append(dict(script=name,exit_code=proc.returncode,
                                seconds=time.monotonic()-t,log=str(log.relative_to(ROOT))))
            (out/"run_summary.json").write_text(json.dumps(records,indent=2)+"\n")
            if proc.returncode:
                raise RuntimeError(f"{name} failed; inspect {log}")
    print("All seven processes completed. Inspect the recorded residuals and tests.")

if __name__=="__main__":
    main()
