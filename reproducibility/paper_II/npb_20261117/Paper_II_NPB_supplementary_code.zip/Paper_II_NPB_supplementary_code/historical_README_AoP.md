# Scalar Paper II — Annals of Physics supplementary checks

Companion to “Modewise freezing, terminal particle structures and local stress
in the Schwarzschild interior”, Francisco R. Villatoro, 2026.

## Provenance and scope

`archived_v110/` contains the original scalar Paper-II scripts and outputs
from `FrancisRVillatoro/schwarzschild-one-particle-reproducibility`, tag v1.1.0,
DOI 10.5281/zenodo.23154909. They are preserved, not silently corrected.
`check_AoP_revision.py` and `check_scalar_Ward.py` are the additional audit
scripts. This supplement has no newly invented DOI and does not require the
fermionic v1.2.0 candidate. No manuscripts are uploaded by these scripts.

`reference_results/` contains the recorded outputs accompanying the submission.
`environment.json` gives the recorded package versions. Floating-point values
are diagnostics, not interval certificates. The proofs in the manuscript
establish the general theorems. New tests include the physical normalization
of a horizon-flux diagnostic, NOT a numerical exterior Unruh-scattering problem.

## Execute

With Python 3.10 or later (tested here with Python 3.13.5):

```sh
python -m pip install -r requirements.txt
python run_all_checks.py
```

Run the driver from this extracted directory. It stops with a nonzero exit
status if a script fails. The five archived scripts run in an automatically
removed temporary copy. Their logs are written to `results/archived_runs/`.
The two new scripts write CSV/JSON results to `results/`. The delivered
`reference_results/` remain unchanged. Run time depends on the machine.

Most archived scripts report residuals but do not assert every printed value.
An exit code of zero is NOT a certificate of every printed result. The new
scripts explicitly assert their stated diagnostic thresholds. Compare the
result files, not elapsed times or integrator tolerances alone.

## Files

- `swave_refinement.csv`: endpoint and tolerance refinement of K |beta_H|^2.
- `Jost_IR_diagnostic.csv`: low-frequency bound diagnostic on l=1.
- `squeezed_pair.csv`: finite-particle weight of an increasingly squeezed pair.
- `normalized_packet.csv`: scalar density for the normalized horizon profile.
- `packet_refinement.csv`: spectral quadrature and tolerance refinements.
- `audit_summary.json`: the 29 checks and explicit thresholds.
- `scalar_Ward_jets.json`: 20 independently constructed on-shell two-jet tests.

The angular-node stress values in the original raw script are divided by
Z=2.5086142772483844 in the normalized diagnostic. The ratios at nonzero
leading coefficient are invariant under that normalization. See the
supplementary PDF for the corresponding continuum modes and profile.

No absolute vacuum RSET, no complete exterior transmission matrix, and no
uniform generic-ray scattering remainder is computed here.
