"""Run the preserved independent and Ward checks without changing prior outputs."""
from __future__ import annotations
from pathlib import Path
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent

def main():
    out = ROOT / "validation_NPB_20261117"
    out.mkdir(exist_ok=True)
    env = os.environ.copy()
    env.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1",
               PYTHONDONTWRITEBYTECODE="1", PYTHONUNBUFFERED="1")
    env.pop("SKIP_A", None)
    import numpy, scipy, sympy, mpmath
    versions = {"python": platform.python_version(), "platform": platform.platform(),
                "numpy": numpy.__version__, "scipy": scipy.__version__,
                "sympy": sympy.__version__, "mpmath": mpmath.__version__}
    (out / "environment.json").write_text(json.dumps(versions, indent=2) + "\n")
    records = []
    with tempfile.TemporaryDirectory(prefix="npb_scalar_checks_") as temp:
        work = Path(temp)
        shutil.copytree(ROOT / "independent_audit", work / "independent_audit")
        shutil.copy2(ROOT / "check_scalar_Ward.py", work / "check_scalar_Ward.py")
        (work / "results").mkdir()
        jobs = [("audit_sym.py", work / "independent_audit"),
                ("check_scalar_Ward.py", work),
                ("audit_num.py", work / "independent_audit")]
        for name, cwd in jobs:
            print("Running", name, flush=True)
            started = time.monotonic()
            log = out / (name + ".log")
            with log.open("w", encoding="utf-8") as handle:
                proc = subprocess.run([sys.executable, name], cwd=cwd, env=env,
                                      stdout=handle, stderr=subprocess.STDOUT)
            records.append({"script": name, "exit_code": proc.returncode,
                            "seconds": time.monotonic() - started,
                            "log": log.name})
            (out / "run_summary.json").write_text(json.dumps(records, indent=2) + "\n")
            if proc.returncode:
                raise RuntimeError(name + " failed; inspect " + str(log))
            for product in (work / "results").glob("*.json"):
                shutil.copy2(product, out / product.name)
            print("Completed", name, flush=True)
    print("Checks finished. Inspect numerical residuals as well as exit codes.")

if __name__ == "__main__":
    main()
